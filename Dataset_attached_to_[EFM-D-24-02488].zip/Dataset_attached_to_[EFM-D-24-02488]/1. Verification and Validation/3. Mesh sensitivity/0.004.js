SetCurDir(GetSrcDir());

dyna.Clear();

geo.Clear();

mesh.Clear();

doc.ClearResult();
//力学计算开关
dyna.Set("Mechanic_Cal 1");
//设置三个方向的重力加速度
dyna.Set("Gravity 0.0  0.0 -9.8");

///////////////////////////////////////
//关闭大变形计算开关
dyna.Set("Large_Displace 0");

//打开虚质量计算开关
dyna.Set("If_Virtural_Mass 1");

//设置虚质量时步为0.5
dyna.Set("Virtural_Step 0.5");

//设置满足稳定条件的系统不平衡率
dyna.Set("UnBalance_Ratio 1e-4");


//关接触更新计算开关
dyna.Set("If_Renew_Contact 0");

//设置接触容差为0
dyna.Set("Contact_Detect_Tol 1e-3");
//是否仅通过单元拓扑信息寻找初始接触 
dyna.Set("If_Find_Contact_OBT 1");



//快速渗流模型
//dyna.Set("Seepage_Mode 4");



//关闭裂隙渗流计算开关
dyna.Set("FracSeepage_Cal 0");

//包含裂隙渗流计算模块，开辟相应内存
dyna.Set("Config_FracSeepage 1");

//渗流计算时裂隙单元允许的最大裂隙开度
dyna.Set("FS_MaxWid 1e-4");

//关闭裂隙渗流与固体耦合开关（孔隙渗流无此开关）
dyna.Set("FS_Solid_Interaction 0");
//裂隙渗流模型为液体渗流时，是否采用增量法计算液体压力及饱和度，0 全量法，1增量法
dyna.Set("FS_Cal_Incremental 1");
//打开裂缝显示开关
dyna.Set("Config_Crack_Show 1");



/*
//开启孔隙渗流开关
//dyna.Set("PoreSeepage_Cal 1");
//包含渗流计算模块，开辟相应内存
dyna.Set("Config_FracSeepage 1");

//打开裂隙渗流计算开关
//dyna.Set("FracSeepage_Cal 1");
//打开裂隙渗流与孔隙渗流的耦合开关
//dyna.Set("FS_PoreS_Interaction 1")
*/


//设置计算结果的输出间隔为1000步
//dyna.Set("Output_Interval 1000");





//////////////////模型
var Fid1 = geo.GenRect(0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.004);

var Lid1 = geo. GenLine(0.4, 0.5, 0.0, 0.6, 0.5, 0.0, 0.004, 0.004);

var id1 = geo.GenSurface (Fid1, 1);

geo.SetHardLineToFace(Lid1, id1);

mesh.GenMeshByGmsh(2);

dyna.GetMesh();


//切割单元面
blkdyn.CrtIFace();

//更新接触面网格
blkdyn.UpdateIFaceMesh();
//blkdyn.ImportGrid("gmsh","GDEM.msh");
//////////////////模型

//设定所有单元的本构为线弹性本构
blkdyn.SetModel("linear");

//设定材料参数。材料密度（kg/m3）弹性模量（Pa）泊松比、粘聚力（Pa）抗拉强度（Pa）内摩擦角（°）剪胀角（°）单元的组号或 组号上限、组号下线
blkdyn.SetMat(2000, 210e9, 0.25, 5e6, 3e6, 35, 10);


//设定所有接触面的本构为线弹性模型
blkdyn.SetIModel("linear");
//接触面刚度从单元中获取
blkdyn.SetIStiffByElem(10.0);

//接触面强度从单元中获取 法向刚度（单位：Pa/m），单位面积上的切向刚度（单位：Pa/m），摩擦角（单位：度），内聚力（单位：Pa），抗拉强度（单位：Pa）
blkdyn.SetIStrengthByElem();
blkdyn.SetIMatByCoord(1e9, 1e9, 30, 0, 0, 0.4,0.6,0.495,0.505,-0.1,0.1);

//设定全部节点的局部阻尼系数为0.8
blkdyn.SetLocalDamp(0.8);


//固定模型四周的法向速度，为0.0
blkdyn.FixV("x", 0.0, "x", -0.001, 0.001);
blkdyn.FixV("x", 0.0, "x", 0.999,1.001);
blkdyn.FixV("y", 0.0, "y", -0.001, 0.001);
blkdyn.FixV("y", 0.0, "y", 0.999,1.001);
blkdyn.FixV("z", 0.0, "z", -0.001, 0.001);

//创建裂隙单元
fracsp.CreateGridFromBlock (2);

//设置裂隙渗流参数，依次为密度、体积模量、渗透系数、裂隙初始开度、组号下限及组号上限
fracsp.SetPropByGroup(1000.0, 1e8,1.333e-6, 5e-6,1,11);




//弹性场  求解至稳定
dyna.Solve();

////////////////////////////////////渗流

//定义三个方向梯度值
var fArrayGrad = [0.0, 0.0, 0.0];
//点源的渗流压力施加为 22MPa
fracsp.ApplyConditionByCoord("pp",22e6, fArrayGrad, 0.4, 0.6,0.49, 0.51, -0.001, 0.001);





//检测竖向位移
dyna.Monitor("fracsp", "sc_width", 0.5, 0.5, 0);
dyna.Monitor("fracsp", "sc_width", 0.505, 0.5, 0);
dyna.Monitor("fracsp", "sc_width", 0.51, 0.5,0);
dyna.Monitor("fracsp", "sc_width", 0.515, 0.5, 0);
dyna.Monitor("fracsp", "sc_width", 0.52, 0.5, 0);
dyna.Monitor("fracsp", "sc_width", 0.525, 0.5, 0);
dyna.Monitor("fracsp", "sc_width", 0.53, 0.5,0);
dyna.Monitor("fracsp", "sc_width", 0.535, 0.5, 0);
dyna.Monitor("fracsp", "sc_width", 0.54, 0.5, 0);
dyna.Monitor("fracsp", "sc_width", 0.545, 0.5, 0);
dyna.Monitor("fracsp", "sc_width", 0.55, 0.5,0);
dyna.Monitor("fracsp", "sc_width", 0.555, 0.5, 0);
dyna.Monitor("fracsp", "sc_width", 0.56, 0.5, 0);
dyna.Monitor("fracsp", "sc_width", 0.565, 0.5, 0);
dyna.Monitor("fracsp", "sc_width", 0.57, 0.5,0);
dyna.Monitor("fracsp", "sc_width", 0.575, 0.5, 0);
dyna.Monitor("fracsp", "sc_width", 0.58, 0.5, 0);
dyna.Monitor("fracsp", "sc_width", 0.585, 0.5, 0);
dyna.Monitor("fracsp", "sc_width", 0.59, 0.5,0);
dyna.Monitor("fracsp", "sc_width", 0.595, 0.5, 0);
dyna.Monitor("fracsp", "sc_width", 0.6, 0.5, 0);


dyna.Monitor("block", "ydis", 0.5, 0.5, 0);
dyna.Monitor("block", "ydis", 0.505, 0.5, 0);
dyna.Monitor("block", "ydis", 0.51, 0.5,0);
dyna.Monitor("block", "ydis", 0.515, 0.5, 0);
dyna.Monitor("block", "ydis", 0.52, 0.5, 0);
dyna.Monitor("block", "ydis", 0.525, 0.5, 0);
dyna.Monitor("block", "ydis", 0.53, 0.5,0);
dyna.Monitor("block", "ydis", 0.535, 0.5, 0);
dyna.Monitor("block", "ydis", 0.54, 0.5, 0);
dyna.Monitor("block", "ydis", 0.545, 0.5, 0);
dyna.Monitor("block", "ydis", 0.55, 0.5,0);
dyna.Monitor("block", "ydis", 0.555, 0.5, 0);
dyna.Monitor("block", "ydis", 0.56, 0.5, 0);
dyna.Monitor("block", "ydis", 0.565, 0.5, 0);
dyna.Monitor("block", "ydis", 0.57, 0.5,0);
dyna.Monitor("block", "ydis", 0.575, 0.5, 0);
dyna.Monitor("block", "ydis", 0.58, 0.5, 0);
dyna.Monitor("block", "ydis", 0.585, 0.5, 0);
dyna.Monitor("block", "ydis", 0.59, 0.5,0);
dyna.Monitor("block", "ydis", 0.595, 0.5, 0);
dyna.Monitor("block", "ydis", 0.6, 0.5, 0);


dyna.Set("Time_Now 0");

//设置虚质量时步为0.8
dyna.Set("Virtural_Step 0.5");

//设置计算时步
dyna.Set("Time_Step 1e-7");

dyna.Set("Output_Interval 2000");


//打开裂隙渗流计算开关
dyna.Set("FracSeepage_Cal 1");
//打开裂隙渗流与固体耦合开关（孔隙渗流无此开关）
dyna.Set("FS_Solid_Interaction 1");

//计算20s
dyna.DynaCycle(2.5);


//打印提示信息
print("Solution Finished");







